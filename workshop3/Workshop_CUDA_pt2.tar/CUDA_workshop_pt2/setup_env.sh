#!/bin/bash
export PATH=/chalmers/sw/sup64/cuda_toolkit-11.2.2/bin:$PATH
export LD_LIBRARY_PATH=/chalmers/sw/sup64/cuda_toolkit-11.2.2/lib64:$LD_LIBRARY_PATH


